export class Approvals {
    constructor(
      public policyId:string,
      public userName:string,
    ){}
}
