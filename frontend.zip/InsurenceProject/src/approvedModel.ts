export class ApprovedModel {
    constructor(
      public policyId:string,
      public userName:string,
    ){}
}
